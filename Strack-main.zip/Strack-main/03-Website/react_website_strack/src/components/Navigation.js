import React, { Component } from 'react';
import styles from './styles/Navigation.module.css';

class Navigation extends Component {
    render() { 
        return ( <p className={styles.header}>hello world</p> );
    }
}
 
export default Navigation;