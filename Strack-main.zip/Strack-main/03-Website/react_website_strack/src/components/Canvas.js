import { useEffect, useRef, useState } from "react";
import styles from "./styles/Canvas.module.css";
import image from "./media/mapsmall.png";


const Canvas = (props) => {
  const [Loc, setLoc] = useState([]);
  useEffect(()=>{
    let lengthImage_x = 300; //pixel
    let lengthImage_y = 150; //pixel
    let rangeFromDB_x = props.l_x; //l_x und l_y aus der Datenbank stehen in dieser Liste "data"
    let rangeFromDB_y = props.l_y; 
  
    let x_PercentFromImageLength = (100 * rangeFromDB_x) / 50; //50 = gesamtlänge X der Halle
    let y_PercentFromImageLength = (100 * rangeFromDB_y) / 40; //40 = gesamtlänge Y der Halle
  
    let x_LengthInPixel = (lengthImage_x * x_PercentFromImageLength) / 100; //300 höchst mögliche Pixellänge in diesem Canvas
    let y_LengthInPixel = (lengthImage_y * y_PercentFromImageLength) / 100; //150 höchst mögliche Pixellänge in diesem Canvas
  
    let setListFromPixelPosition = [x_LengthInPixel, y_LengthInPixel];
    setLoc(setListFromPixelPosition);
  },[]);
  
  const canvasRef = useRef(null);

  const draw = (ctx) => {
    ctx.fillStyle = "#000000";
    ctx.beginPath();
    ctx.arc(Loc[0], Loc[1], 2, 0, 2 * Math.PI);
    ctx.fill();
  };

  useEffect(() => {
    const canvas = canvasRef.current;
    const context = canvas.getContext("2d");
    context.clearRect(0, 0, canvas.width, canvas.height);
    //Our draw come here
    draw(context);
  }, [draw]);

  return (
    <div className={styles.wrapper}>
      <div>
        <canvas className={styles.canvas} ref={canvasRef}></canvas>
      </div>
    </div>
  );
};

export default Canvas;
