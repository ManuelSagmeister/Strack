import logo from './logo.svg';
import './App.css';

import Request from './components/Request';
import Canvas from './components/Canvas';


function App() {
  return (
    <div className="App">
      
      <Request/>
      
     
      
    </div>
  );
}

export default App;
